Example Scripts
===============

This page presents a collection of example scripts written using Mule to perform
a variety of common tasks; this should highlight the intended/recommended 
methods for getting the most out of the API.

.. toctree::
   :maxdepth: 2

   examples_headers.rst
   examples_filtering.rst
   examples_data.rst
   examples_multi.rst

